setup() ;
% oriimdb = load('D:\casia_data\casia10hwimdb.mat') ;
% netpret=load('D:\casia_data\text-small200_32_numfvt_32\net-epoch-3000.mat');     
% % 
 oriimdb = load('D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used-mnist\data\mnist\imdb.mat') ;
 netpret=load('D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used-mnist\data\text-small200_32_numfvt_32\net-epoch-3000.mat');     
 

last2layer=netpret.last2layer;

net=netpret.net;
imdb=oriimdb;
%  imdb=oriimdb.casia10hwimdb;
imdb.images.data=single(imdb.images.data);
% Deploy: remove loss
net.layers(end) = [] ;


        figure(1)
        cntfg=0;
        for iii=1:32
            cntfg=cntfg+1;
            subplot(4,8,cntfg) ;
            imagesc(net.layers{1}.weights{1}(:,:,1,iii));
            axis off image ;
     
        end
      colormap gray ;
        
        
        
        


