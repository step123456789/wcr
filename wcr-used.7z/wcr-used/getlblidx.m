function lblidx=getlblidx(imlbl)
samnum=size(imlbl,2);
lblidx{1}=[];
for i=1:samnum
    sameidx=find(imlbl==imlbl(i));
    lblidx{i}=sameidx;
end
   
