function [net, info] = cnn_mnist_usepret(varargin)
% CNN_MNIST  Demonstrated MatConNet on MNIST

run(fullfile(fileparts(mfilename('fullpath')),...
    '..', '..', 'matlab', 'vl_setupnn.m')) ;
opts.batchNormalization = false ;
opts.networkType = 'simplenn' ;
[opts, varargin] = vl_argparse(opts, varargin) ;
sfx = opts.networkType ;
if opts.batchNormalization, sfx = [sfx '-bnorm'] ; end
opts.expDir = fullfile(vl_rootnn, 'data', ['mnist-baseline' sfx]) ;
[opts, varargin] = vl_argparse(opts, varargin) ;
opts.dataDir = fullfile(vl_rootnn, 'data', 'mnist') ;
opts.imdbPath = fullfile(opts.expDir, 'imdb.mat');
opts.train = struct() ;
opts = vl_argparse(opts, varargin) ;
if ~isfield(opts.train, 'gpus'), opts.train.gpus = []; end;


oriimdb = load('D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used\data/mnist/imdb.mat') ;
oriimdb.images.data=(oriimdb.images.data)/255;
eachtrainnum=[10,50,100,500,1000];
bachsize=[5 10 20 50 100];
clanum=10;
for eachidx=1:2
    for numf=8:8:24
        % --------------------------------------------------------------------
        %                                                         Prepare data
        % % --------------------------------------------------------------------
        load(['D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used\idx_label\used_idx_labels' num2str(eachtrainnum(eachidx)) '.mat']);
        imdb=oriimdb;
        trainvalidx=[usedtrainidx 60001:70000];
        imdb.images.data=oriimdb.images.data(:,:,:,trainvalidx);
        imdb.images.set=[ones(1,eachtrainnum(eachidx)*clanum) ones(1,10000)*3];
        imdb.images.labels=[usedlabels oriimdb.images.labels(60001:70000)];
        imdb.images.label=imdb.images.labels;
        for bsidx=1:5
            % --------------------------------------------------------------------
            %                                                         Prepare Net 1
            % % --------------------------------------------------------------------
            netpret=load(['D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used\data\text-small' num2str(eachtrainnum(eachidx)) '_' num2str(numf) '\net-epoch-3000.mat']);
            net=cnn_mnist_init_pret(netpret,numf,bachsize(bsidx),'batchNormalization', opts.batchNormalization, 'networkType', opts.networkType) ;
          
            %net = cnn_mnist_init_pretlast3('batchNormalization', opts.batchNormalization, 'networkType', opts.networkType) ;
            % --------------------------------------------------------------------
            %                                                         Prepare Net 2
            % % % --------------------------------------------------------------------
            % netpret=load(['D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used\data\text-small' num2str(eachtrainnum(eachidx)) '_' num2str(numf) '\net-epoch-3000.mat']);
            % netlast3=load('C:\practical-cnn-reg-2016a_ori\practical-cnn-reg-2016a\matconvnet\examples\mnist\netlast3.mat');
            % net=cnn_mnist_init_pret_last3(netpret,netlast3,'batchNormalization', opts.batchNormalization, 'networkType', opts.networkType) ;
            
            net.meta.classes.name = arrayfun(@(x)sprintf('%d',x),1:10,'UniformOutput',false) ;
            % %1111
            % netpret.layers{end}.class=imdb.images.labels;
            % respret=vl_simplenn(netpret,imdb.images.data);
            % imdb.images.data=respret(7).x;
            % --------------------------------------------------------------------
            %                                                                Train
            % --------------------------------------------------------------------
            switch opts.networkType
                case 'simplenn', trainfn = @cnn_train ;
                case 'dagnn', trainfn = @cnn_train_dag ;
            end
            opts.expDir = ['D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used\pret_result\trainnum_' num2str(eachtrainnum(eachidx)) 'numf_' num2str(numf) 'batchsize_' num2str(bachsize(bsidx))];
            [net, info] = trainfn(net,imdb, getBatch(opts), ...
                'expDir', opts.expDir, ...
                net.meta.trainOpts, ...
                opts.train, ...
                'val', find(imdb.images.set == 3)) ;
        end
    end
end
%save('netlast3.mat','net');
% --------------------------------------------------------------------
function fn = getBatch(opts)
% --------------------------------------------------------------------
switch lower(opts.networkType)
    case 'simplenn'
        fn = @(x,y) getSimpleNNBatch(x,y) ;
    case 'dagnn'
        bopts = struct('numGpus', numel(opts.train.gpus)) ;
        fn = @(x,y) getDagNNBatch(bopts,x,y) ;
end

% --------------------------------------------------------------------
function [images, labels] = getSimpleNNBatch(imdb, batch)
% --------------------------------------------------------------------
images = imdb.images.data(:,:,:,batch) ;
labels = imdb.images.labels(1,batch) ;

% --------------------------------------------------------------------
function inputs = getDagNNBatch(opts, imdb, batch)
% --------------------------------------------------------------------
images = imdb.images.data(:,:,:,batch) ;
labels = imdb.images.labels(1,batch) ;
if opts.numGpus > 0
    images = gpuArray(images) ;
end
inputs = {'input', images, 'label', labels} ;

