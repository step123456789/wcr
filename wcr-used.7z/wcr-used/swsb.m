setup() ;
% 
% oriimdb = load('D:\casia_data\casia10hwimdb.mat') ;
% netpret=load('D:\casia_data\net-epoch-1000.mat');     %\text-small200_16_numfvt_16
%   load('D:\casia_data\used_idx_labels200.mat');


 oriimdb = load('D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used-mnist\data\mnist\imdb.mat') ;
 netpret=load('D:\cnn-autoEncoder-for-mnist\data\text-small200_16_numfvt_16\net-epoch-1000.mat');     
 load('D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used-mnist\idx_label\used_idx_labels200.mat');



net=netpret.net;
%net=cnn_mnist_init(16,16,16,'batchNormalization', true, 'networkType', 'simplenn') ;
              
 imdb=oriimdb;
 
 %imdb=oriimdb.casia10hwimdb;


 imdb.images.data=imdb.images.data(:,:,:,usedtrainidx);
 imdb.images.set=imdb.images.set(1,usedtrainidx);
 imdb.images.labels=imdb.images.labels(1,usedtrainidx);
imdb.images.data=single(imdb.images.data);
% Deploy: remove loss
net.layers(end) = [] ;
 res = vl_simplenn(net, imdb.images.data) ;
 preds = res(7).x ;
 
 sw=0;
 sb=0;
 for i=1:10
     idx=find( imdb.images.labels==i);
     meanfea=mean(preds(:,:,:,idx),4);
     
     for  j=1:size(idx,2)
         sw=sw+sum(sum(sum((preds(:,:,:,idx(j))-meanfea).*(preds(:,:,:,idx(j))-meanfea))))^0.5;
     end
 end
 meanall=mean(preds,4);
 for i=1:10
     idx=find( imdb.images.labels==i);
     meanfea=mean(preds(:,:,:,idx),4);
     sb=sb+sum(sum(sum((meanfea-meanall).*(meanfea-meanall))))^0.5;
 end
 sw=sw/2000;
 sb=sb/10;
 swdsb=sw/sb;
     
      
        
        
        


