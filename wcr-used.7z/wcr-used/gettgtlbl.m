function tgtlbl=gettgtlbl(imlbl,eachtrainnum,clanum)
tgtlbl=zeros(eachtrainnum,clanum);
for i=1:clanum
    sameidx=find(imlbl==i);
    for j=1:eachtrainnum
        tgtlbl(j,i)=sameidx(j);
    end
end
   
