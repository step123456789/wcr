setup() ;
% oriimdb = load('D:\casia_data\casia10hwimdb.mat') ;
% netpret=load('D:\casia_data\text-small200_16_numfvt_16\net-epoch-3000.mat');     
% 
 oriimdb = load('D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used-mnist\data\mnist\imdb.mat') ;
 netpret=load('D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used-mnist\data\text-small200_16_numfvt_16\net-epoch-3000.mat');     
 

last2layer=netpret.last2layer;

net=netpret.net;
 imdb=oriimdb;
 %imdb=oriimdb.casia10hwimdb;
imdb.images.data=single(imdb.images.data);
% Deploy: remove loss
net.layers(end) = [] ;

train = find(imdb.images.set == 1) ;
val = find(imdb.images.set == 2) ;
 figure(1)
 cntfg=0;
 for jjj=1:5
usedidx=find(imdb.images.labels == jjj) ;

       
        for iii=1:2
            cntfg=cntfg+1;
            subplot(10,17,cntfg) ;
            imagesc(1-imdb.images.data(:,:,:,usedidx(iii)),[0 1]) ;
            axis off image ;
                res = vl_simplenn(net, imdb.images.data(:,:,:,usedidx(iii))) ;
                preds = res(7).x ;
                for jjj=1:16
                     cntfg=cntfg+1;
                    subplot(10,17,cntfg) ;
                    imagesc(preds(:,:,jjj)) ;
                    axis off image ;
                end
               
          
        end
     %   colormap gray ;
 end
        
        
        colormap gray ;

        
        
        


