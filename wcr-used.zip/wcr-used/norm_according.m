function normimg=norm_according(img,rho)
width=size(img,2);
height=size(img,1);
Hi=zeros(1,height);
Vj=zeros(1,width);
normimg=img;
for i=1:height
    Hi(i)=0;
    for j=1:width
        Hi(i)=Hi(i)+rho(i,j)+0.01;
    end
end
for j=1:width
    Vj(j)=0;
    for i=1:height
       Vj(j)=Vj(j)+rho(i,j)+0.01;
    end
end
CHall=sum(Hi);
CVall=sum(Vj);
cntinimg=zeros(height,width);
isvrow=zeros(height,width);
for i=1:height
    for j=1:width
        sumi=sum(Hi(1:i));
        sumj=sum(Vj(1:j));
        zmi=round(sumi*height/CHall);
		zmj=round(width*sumj/CVall);
        if zmi<1
            zmi=1;
        end
        if zmj<1
            zmj=1;
        end
        normimg(zmi,zmj)=normimg(zmi,zmj)+img(i,j);
        cntinimg(zmi,zmj)=cntinimg(zmi,zmj)+1;
        isvrow(zmi,zmj)=1;
    end
end
for i=1:height
    for j=1:width
        if cntinimg(i,j)>0
            normimg(i,j)= normimg(i,j)/cntinimg(i,j);
        end
    end
end
for i=1:height
    for j=1:width
        if isvrow(i,j)==0
            sumv=0;cnt=0;
            for r=-1:1
                for c=-1:1
                    if i+r>0 && i+r<height+1 && j+c>0 && j+c<width+1
                        if isvrow(i+r,j+c)>0
                            sumv=sumv+normimg(i+r,j+c);
                            cnt=cnt+1;
                        end
                    end
                end
            end
            if cnt>0
                normimg(i,j)=sumv/cnt;
            end
        end
    end
end
	
    limg=zeros(32,32);
    limg(3:30,3:30)=normimg;
    normimg=imresize(limg,[28,28]);

	
