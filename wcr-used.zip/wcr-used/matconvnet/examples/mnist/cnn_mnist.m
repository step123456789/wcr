function [net, info] = cnn_mnist(ispret,expdir,varargin)
% CNN_MNIST  Demonstrated MatConNet on MNIST

run(fullfile(fileparts(mfilename('fullpath')),...
    '..', '..', 'matlab', 'vl_setupnn.m')) ;
opts.batchNormalization = false ;
opts.networkType = 'simplenn' ;
[opts, varargin] = vl_argparse(opts, varargin) ;
sfx = opts.networkType ;
if opts.batchNormalization, sfx = [sfx '-bnorm'] ; end
opts.expDir = fullfile(vl_rootnn, 'data', ['mnist-baseline' sfx]) ;
[opts, varargin] = vl_argparse(opts, varargin) ;
opts.dataDir = fullfile(vl_rootnn, 'data', 'mnist') ;
opts.imdbPath = fullfile(opts.expDir, 'imdb.mat');
opts.train = struct() ;
opts = vl_argparse(opts, varargin) ;
if ~isfield(opts.train, 'gpus'), opts.train.gpus = []; end;

oriimdb = load('D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used-mnist\data\mnist\imdb.mat') ;
oriimdb.images.data=(oriimdb.images.data)/255;

eachtrainnum=[50,100,200,500];
clanum=10;
bachsize=[10 50];
fp=fopen(['RES_alltraintest_pretlast3_test10000_' num2str(ispret) '.txt'],'w');
for eachidx=4:4
    for numf=16:16:32
        for numfconvt=16:16:32
            
            % --------------------------------------------------------------------
            %                                                         Prepare data
            % % --------------------------------------------------------------------
            load(['D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used-mnist\idx_label\used_idx_labels' num2str(eachtrainnum(eachidx)) '.mat']);
           
       
            for bsidx=1:2
                % --------------------------------------------------------------------
                %                                                         Prepare Net 1
                % % --------------------------------------------------------------------
                imdb=oriimdb;
%                 imdb.images.data=oriimdb.images.data(:,:,:,[usedtrainidx 60001:70000]);
%                 imdb.images.set=[ones(1,size(usedtrainidx,2)) ones(1,10000)*3];
%                 imdb.images.label=oriimdb.images.labels(1,[usedtrainidx 60001:70000]);
%                 imdb.images.labels=imdb.images.label;
                
                if ispret==0
                    net=cnn_mnist_init(numf,numfconvt,bachsize(bsidx),'batchNormalization', opts.batchNormalization, 'networkType', opts.networkType) ;
                else
                    if ispret==1
                        % netpret=load(['D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used-mnist\data\text-small' num2str(eachtrainnum(eachidx)) '_' num2str(numf) '_numfvt_' num2str(numfconvt) '\net-epoch-1000.mat']);
                       
                        netpret=load(['D:\cnn-autoEncoder-for-mnist\data\text-small' num2str(eachtrainnum(eachidx)) '_' num2str(numf) '_numfvt_' num2str(numfconvt) '\net-epoch-1000.mat']);
                        net=cnn_mnist_init_pret(netpret,numf,bachsize(bsidx),'batchNormalization', opts.batchNormalization, 'networkType', opts.networkType) ;
                        
                    else
                        
                        netpret=load(['D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used-mnist\data\text-small' num2str(eachtrainnum(eachidx)) '_' num2str(numf) '_numfvt_' num2str(numfconvt) '\net-epoch-1000.mat']);
                        netpret3=load(['D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used-mnist\last3_1000_test10000_result\trainnum_' ...
                            num2str(eachtrainnum(eachidx)) 'numf_' num2str(numf)  'numfvt_' num2str(numfconvt) 'batchsize_' num2str(bachsize(bsidx)) '\net-epoch-40.mat']);
%                           netpret=load(['D:\cnn-autoEncoder-for-mnist\data\text-small' num2str(eachtrainnum(eachidx)) '_' num2str(numf) '_numfvt_' num2str(numfconvt) '\net-epoch-1000.mat']);
% 
%                             netpret3=load(['D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used-mnist\last3_ae_1000_test10000_result\trainnum_' ...
%                              num2str(eachtrainnum(eachidx)) 'numf_' num2str(numf)  'numfvt_' num2str(numfconvt) 'batchsize_' num2str(bachsize(bsidx)) '\net-epoch-40.mat']);
                         
                        net=cnn_mnist_init_pretandlast3(netpret,netpret3,numf,bachsize(bsidx),'batchNormalization', opts.batchNormalization, 'networkType', opts.networkType) ;
                      
                                                
%                       %   netpret=load(['D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used-mnist\data\text-small' num2str(eachtrainnum(eachidx)) '_' num2str(numf) '_numfvt_' num2str(numfconvt) '\net-epoch-1000.mat']);
%                           netpret=load(['D:\cnn-autoEncoder-for-mnist\data\text-small' num2str(eachtrainnum(eachidx)) '_' num2str(numf) '_numfvt_' num2str(numfconvt) '\net-epoch-1000.mat']);
%                       
%                          netpret=netpret.net;
%                         netpret.layers(end) = [] ;
%                         netpret.layers{end}.class=imdb.images.labels;
%                         respret=vl_simplenn(netpret,imdb.images.data);
%                         imdb.images.data=respret(7).x;
%                         net = cnn_mnist_init_last3(numf,bachsize(bsidx),'batchNormalization', opts.batchNormalization, 'networkType', opts.networkType);
                    end
                end
                
                net.meta.classes.name = arrayfun(@(x)sprintf('%d',x),1:clanum,'UniformOutput',false) ;
                
                % --------------------------------------------------------------------
                %                                                                Train
                % --------------------------------------------------------------------
                switch opts.networkType
                    case 'simplenn', trainfn = @cnn_train ;
                    case 'dagnn', trainfn = @cnn_train_dag ;
                end
                opts.expDir = ['D:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used-mnist\' expdir '\trainnum_' num2str(eachtrainnum(eachidx)) 'numf_' num2str(numf) 'numfvt_' num2str(numfconvt) 'batchsize_' num2str(bachsize(bsidx))];
                [net, info] = trainfn(net,imdb, getBatch(opts), ...
                    'expDir', opts.expDir, ...
                    net.meta.trainOpts, ...
                    opts.train, ...
                    'val', find(imdb.images.set == 3)) ;
                
                fprintf(fp,'%d %d %d %d %f\n',eachidx,numf,numfconvt,bsidx,info.('val').error(1,end));
            end
        end
    end
end
fclose(fp);
% --------------------------------------------------------------------
function fn = getBatch(opts)
% --------------------------------------------------------------------
switch lower(opts.networkType)
    case 'simplenn'
        fn = @(x,y) getSimpleNNBatch(x,y) ;
    case 'dagnn'
        bopts = struct('numGpus', numel(opts.train.gpus)) ;
        fn = @(x,y) getDagNNBatch(bopts,x,y) ;
end

% --------------------------------------------------------------------
function [images, labels] = getSimpleNNBatch(imdb, batch)
% --------------------------------------------------------------------
images = imdb.images.data(:,:,:,batch) ;
labels = imdb.images.labels(1,batch) ;

% --------------------------------------------------------------------
function inputs = getDagNNBatch(opts, imdb, batch)
% --------------------------------------------------------------------
images = imdb.images.data(:,:,:,batch) ;
labels = imdb.images.labels(1,batch) ;
if opts.numGpus > 0
    images = gpuArray(images) ;
end
inputs = {'input', images, 'label', labels} ;

