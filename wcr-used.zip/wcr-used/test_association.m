setup() ;
%% Part 3.1: Prepare the data
oriimdb = load('data/mnist/imdb.mat') ;
%imdb.images.data=(-imdb.images.data)/255;
oriimdb.images.data=(oriimdb.images.data)/255;
%dataMean = mean(imdb.images.data(:,:,:,imdb.images.set == 1), 4);
%imdb.images.data = bsxfun(@minus, imdb.images.data, dataMean) ;
%dataMean = mean(imdb.images.data(:,:,:,imdb.images.set == 1), 4);
eachtrainnum=[50,100,200,500];
clanum=10;
for eachidx=1:4
    for numf=8:8:16
    for numfconvt=8:8:16
        sgc_exist = exist(['idx_label/used_idx_labels' num2str(eachtrainnum(eachidx)) '.mat'], 'file');
        if sgc_exist==0
            [usedtrainidx usedlabels]=gettrainidx(oriimdb,eachtrainnum(eachidx),clanum);
            save (['idx_label/used_idx_labels' num2str(eachtrainnum(eachidx)) '.mat'],'usedtrainidx','usedlabels');
        else
            load(['idx_label/used_idx_labels' num2str(eachtrainnum(eachidx)) '.mat']);
        end
        imdb=oriimdb;
        imdb.images.data=oriimdb.images.data(:,:,:,usedtrainidx);
        imdb.images.set=ones(1,eachtrainnum(eachidx)*clanum);
        imdb.images.labels=usedlabels;
        imdb.images.label=imdb.images.labels;
        tgtlbl=gettgtlbl(usedlabels,eachtrainnum(eachidx),clanum);
        %% Part 3.2: Create a network architecture
        sgc_exist = exist(['last2layer/last2layer_each' num2str(eachtrainnum(eachidx)) '_numf_' num2str(numf)  '_numfvt_' num2str(numfconvt) '.mat'], 'file'); 
        if sgc_exist==0
            last2layer=init_last2layer_for_asso(eachtrainnum(eachidx),numf,numfconvt);
             isupdated=zeros(1,eachtrainnum(eachidx));
        else
            load(['last2layer/last2layer_each' num2str(eachtrainnum(eachidx)) '_numf_' num2str(numf)   '_numfvt_' num2str(numfconvt) '.mat']);
             isupdated=ones(1,eachtrainnum(eachidx));
        end
        
        net = initializeSmallCNN_mnist(numf,numfconvt) ;
        %net = initializeLargeCNN() ;
        % Display network
        vl_simplenn_display(net) ;
        % Evaluate network on an image
        res = vl_simplenn(net, imdb.images.data(:,:,:,1)) ;
        
        figure(32) ; clf ; colormap gray ;
        set(gcf,'name', 'Part 3.2: network input') ;
        subplot(1,2,1) ;
        imagesc(res(1).x) ; axis image off  ;
        title('CNN input') ;
        
        set(gcf,'name', 'Part 3.2: network output') ;
        subplot(1,2,2) ;
        imagesc(res(end).x) ; axis image off  ;
        title('CNN output (not trained yet)') ;
        
        %% Part 3.3: learn the model
        
        % Add a loss (using a custom layer)
        net = addCustomLossLayer(net, @l2LossForward, @l2LossBackward) ;
        
        % Extra: uncomment the following line to use your implementation
        % of the L1 loss
        %net = addCustomLossLayer(net, @l1LossForward, @l1LossBackward) ;
        
        % Train
        trainOpts.expDir = ['data/text-small' num2str(eachtrainnum(eachidx)) '_' num2str(numf)  '_numfvt_' num2str(numfconvt) ];
        trainOpts.gpus = [] ;
        % Uncomment for GPU training:
        %trainOpts.expDir = 'data/text-small-gpu' ;
        %trainOpts.gpus = [1] ;
        trainOpts.batchSize = 1 ;
        trainOpts.learningRate = 0.01 ;
        trainOpts.plotDiagnostics = false ;
        %trainOpts.plotDiagnostics = true ; % Uncomment to plot diagnostics
        trainOpts.numEpochs = 3000;
        trainOpts.errorFunction = 'none' ;
        
        
        [net, last2layer] = cnn_train_multitarget(net, imdb,tgtlbl,last2layer,isupdated, @getBatch, trainOpts) ;
        save (['last2layer/last2layer_each' num2str(eachtrainnum(eachidx)) '_numf_' num2str(numf)  '_numfvt_' num2str(numfconvt)  '.mat'],'last2layer');
        % Deploy: remove loss
%         net.layers(end) = [] ;
        
        %% Part 3.4: evaluate the model
        
%         train = find(imdb.images.set == 1) ;
%         %val = find(imdb.images.set == 2) ;
%        % load('C:\practical-cnn-reg-2016a-batchsize1-fea28281-train-used\data\text-small10_128\net-epoch-100.mat');
%         figure
%         cntfg=0;
%         for iii=1:5
%             cntfg=cntfg+1;
%             subplot(5,1+eachtrainnum(eachidx),cntfg) ;
%             imagesc(imdb.images.data(:,:,:,iii),[0 1]) ;
%             axis off image ;title(num2str(imdb.images.label(iii)-1)) ;
%             
%             for jjj=1:eachtrainnum(eachidx)
%                 for ffff=1:size(last2layer{1}.layers,2)
%                   net.layers{end-ffff+1}=last2layer{jjj}.layers{size(last2layer{1}.layers,2)+1-ffff};
%                end
%               
%                 res = vl_simplenn(net, imdb.images.data(:,:,:,iii)) ;
%                 preds = res(end).x ;
%                 cntfg=cntfg+1;
%                 subplot(5,1+eachtrainnum(eachidx),cntfg) ;
%                 imagesc(preds(:,:,:,1),[0 1]) ;
%                 axis off image ;title(num2str(imdb.images.label(jjj)-1)) ;
%             end
%         end
%         colormap gray ;
    end
    end
end