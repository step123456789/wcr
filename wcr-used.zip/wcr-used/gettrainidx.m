function [usedtrainidx,usedlabels]=gettrainidx(imdb,usednum,clanum)
usedtrainidx=[];
usedlabels=[];
for i=1:clanum
    curidx=find(imdb.images.labels==i);
    usedtrainidx=[usedtrainidx curidx(1:usednum)];
    usedlabels=[usedlabels repmat(i,1,usednum)];
end
rdidx=randperm(usednum*clanum);
usedtrainidx=usedtrainidx(rdidx);
usedlabels=usedlabels(rdidx);
